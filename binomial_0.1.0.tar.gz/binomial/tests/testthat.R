library(testthat)
library(cointoss)

test_check("cointoss")
